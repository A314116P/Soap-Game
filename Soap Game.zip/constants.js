export var GAME_STATE = {
    PLAYING: 'playing',
    WON: 'won',
    LOST: 'lost'
};
