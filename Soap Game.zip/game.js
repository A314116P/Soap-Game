function _class_call_check(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _create_class(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
import * as THREE from 'three';
import { Player } from './player.js';
import { Maze } from './maze.js';
import { UI } from './ui.js';
import { GAME_STATE } from './constants.js';
export var Game = /*#__PURE__*/ function() {
    "use strict";
    function Game(container) {
        _class_call_check(this, Game);
        this.container = container;
        this.width = window.innerWidth;
        this.height = window.innerHeight;
        // Setup renderer
        this.renderer = new THREE.WebGLRenderer({
            antialias: true
        });
        this.renderer.setSize(this.width, this.height);
        this.renderer.shadowMap.enabled = true;
        this.renderer.setClearColor(0x87CEEB); // Sky blue background
        this.container.appendChild(this.renderer.domElement);
        // Setup scene
        this.scene = new THREE.Scene();
        // Setup camera
        this.camera = new THREE.PerspectiveCamera(75, this.width / this.height, 0.1, 1000);
        // Setup lights
        this.setupLights();
        // Create maze
        this.maze = new Maze(this.scene, this);
        // Create player
        this.player = new Player(this.camera, this.maze);
        // Keep reference to soap mesh
        // Keep reference to soap mesh
        this.soapMesh = null;
        this.soapTargetPosition = null; // Add target position for sliding
        this.humanMesh = null; // Reference to the human model
        this.humanTargetQueue = []; // Queue for human's movement targets
        // Create UI
        this.ui = new UI(this.container);
        // Add soap object
        this.addSoap();
        // Add human model
        this.addHuman();
        // Setup resize handler
        window.addEventListener('resize', this.onResize.bind(this));
        // Add raycaster for interactions
        this.raycaster = new THREE.Raycaster();
        this.mouse = new THREE.Vector2();
        this.renderer.domElement.addEventListener('mousedown', this.onMouseDown.bind(this), false);
        // Add key listeners for 'F' key interaction
        document.addEventListener('keydown', this.onKeyDown.bind(this));
        document.addEventListener('keyup', this.onKeyUp.bind(this));
        // Animation loop
        this.clock = new THREE.Clock();
        // Soap interaction state
        this.isFKeyPressed = false;
        this.fKeyHoldTime = 0;
        this.fKeyTargetTime = 1; // 1 second
        // Game state
        this.gameState = GAME_STATE.PLAYING;
        this.restartTimeout = null; // To manage the restart delay
        this.humanIsMoving = false; // Track if human is currently moving
        this.countdownActive = false;
        this.countdownTimer = 30; // 30 seconds
        this.titleHiddenTimestamp = null; // To track when the title was hidden
    }
    _create_class(Game, [
        {
            key: "setupLights",
            value: function setupLights() {
                var _this = this;
                // Ambient light for base illumination
                var ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
                this.scene.add(ambientLight);
                // Directional light for shadows
                var directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
                directionalLight.position.set(0, 10, 0);
                directionalLight.castShadow = true;
                directionalLight.shadow.mapSize.width = 1024;
                directionalLight.shadow.mapSize.height = 1024;
                this.scene.add(directionalLight);
                // Point lights for atmosphere
                var colors = [
                    0xffaa00,
                    0x00aaff,
                    0x00ff6a,
                    0xff00ff
                ];
                colors.forEach(function(color, i) {
                    var light = new THREE.PointLight(color, 1, 15);
                    var x = Math.sin(i * Math.PI / 2) * 5;
                    var z = Math.cos(i * Math.PI / 2) * 5;
                    light.position.set(x, 2, z);
                    _this.scene.add(light);
                });
            }
        },
        {
            key: "addSoap",
            value: function addSoap() {
                var soapGeometry = new THREE.BoxGeometry(0.15, 0.08, 0.05); // Dimensions for a small soap bar
                var soapMaterial = new THREE.MeshStandardMaterial({
                    color: 0xffffff,
                    roughness: 0.8,
                    metalness: 0.1
                });
                var soapMesh = new THREE.Mesh(soapGeometry, soapMaterial);
                // Get player start position and place soap 1 meter behind
                var startPos = this.maze.getStartPosition();
                var soapX = startPos.x;
                var soapY = 0.04; // Place it slightly above the floor (half height)
                var soapZ = startPos.z; // Exactly at the start Z position
                soapMesh.position.set(soapX, soapY, soapZ);
                soapMesh.castShadow = true;
                soapMesh.receiveShadow = true; // Soap can receive shadows too
                this.soapMesh = soapMesh; // Store reference
                this.scene.add(soapMesh);
            }
        },
        {
            key: "addHuman",
            value: function addHuman() {
                // Create a simple capsule shape for the human
                var radius = 0.25;
                var height = 1.7;
                var cylinderHeight = height - 2 * radius;
                var humanMaterial = new THREE.MeshStandardMaterial({
                    color: 0xD2B48C,
                    roughness: 0.8,
                    metalness: 0.1
                });
                // Create group to hold all parts
                var humanGroup = new THREE.Group();
                // Dimensions
                var headRadius = 0.2;
                var torsoHeight = 0.7;
                var torsoWidth = 0.4;
                var torsoDepth = 0.2;
                var limbRadius = 0.08;
                var armLength = 0.6;
                var legLength = 0.7;
                var totalHeight = legLength + torsoHeight + headRadius * 2; // Approximate total height
                // Torso (Box)
                var torsoGeometry = new THREE.BoxGeometry(torsoWidth, torsoHeight, torsoDepth);
                var torsoMesh = new THREE.Mesh(torsoGeometry, humanMaterial);
                torsoMesh.position.y = legLength + torsoHeight / 2;
                torsoMesh.castShadow = true;
                torsoMesh.receiveShadow = true;
                humanGroup.add(torsoMesh);
                // Head (Sphere)
                var headGeometry = new THREE.SphereGeometry(headRadius, 16, 16);
                var headMesh = new THREE.Mesh(headGeometry, humanMaterial);
                headMesh.position.y = legLength + torsoHeight + headRadius; // Place head on top of torso
                headMesh.castShadow = true;
                headMesh.receiveShadow = true;
                humanGroup.add(headMesh);
                // Eyes (Small Spheres)
                var eyeGeometry = new THREE.SphereGeometry(headRadius * 0.15, 8, 8);
                var eyeMaterial = new THREE.MeshStandardMaterial({
                    color: 0x000000
                }); // Black eyes
                var leftEyeMesh = new THREE.Mesh(eyeGeometry, eyeMaterial);
                leftEyeMesh.position.set(-headRadius * 0.4, legLength + torsoHeight + headRadius * 1.1, headRadius * 0.85); // Position on the front-left of the head
                leftEyeMesh.castShadow = true;
                humanGroup.add(leftEyeMesh);
                var rightEyeMesh = new THREE.Mesh(eyeGeometry, eyeMaterial);
                rightEyeMesh.position.set(headRadius * 0.4, legLength + torsoHeight + headRadius * 1.1, headRadius * 0.85); // Position on the front-right of the head
                rightEyeMesh.castShadow = true;
                humanGroup.add(rightEyeMesh);
                // Nose (Small Pyramid/Cone shape - using a Cone for simplicity)
                var noseGeometry = new THREE.ConeGeometry(headRadius * 0.1, headRadius * 0.3, 4); // Small cone
                var noseMesh = new THREE.Mesh(noseGeometry, humanMaterial); // Use skin color
                noseMesh.position.set(0, legLength + torsoHeight + headRadius, headRadius * 0.9); // Position center-front of head
                noseMesh.rotation.x = Math.PI / 2; // Rotate cone to point forward
                noseMesh.castShadow = true;
                humanGroup.add(noseMesh);
                // Mouth (Thin Box)
                var mouthGeometry = new THREE.BoxGeometry(headRadius * 0.5, headRadius * 0.05, headRadius * 0.1);
                var mouthMaterial = new THREE.MeshStandardMaterial({
                    color: 0xAA0000
                }); // Dark red
                var mouthMesh = new THREE.Mesh(mouthGeometry, mouthMaterial);
                mouthMesh.position.set(0, legLength + torsoHeight + headRadius * 0.8, headRadius * 0.9); // Below nose, front of head
                mouthMesh.castShadow = true;
                humanGroup.add(mouthMesh);
                // Ears (Small Boxes)
                var earGeometry = new THREE.BoxGeometry(headRadius * 0.15, headRadius * 0.3, headRadius * 0.25);
                var leftEarMesh = new THREE.Mesh(earGeometry, humanMaterial); // Use skin color
                leftEarMesh.position.set(-headRadius * 1.05, legLength + torsoHeight + headRadius, 0); // Side of the head
                leftEarMesh.castShadow = true;
                humanGroup.add(leftEarMesh);
                var rightEarMesh = new THREE.Mesh(earGeometry, humanMaterial);
                rightEarMesh.position.set(headRadius * 1.05, legLength + torsoHeight + headRadius, 0); // Side of the head
                rightEarMesh.castShadow = true;
                humanGroup.add(rightEarMesh);
                // Arms (Cylinders) - Left Arm
                var leftArmPivot = new THREE.Group();
                leftArmPivot.position.set(-(torsoWidth / 2), legLength + torsoHeight - limbRadius, 0); // Shoulder joint
                humanGroup.add(leftArmPivot);
                humanGroup.leftArmPivot = leftArmPivot;
                var leftArmGeometry = new THREE.CylinderGeometry(limbRadius, limbRadius, armLength, 8);
                var leftArmMesh = new THREE.Mesh(leftArmGeometry, humanMaterial);
                leftArmMesh.position.y = -armLength / 2; // Offset cylinder so its top is at pivot
                leftArmMesh.castShadow = true;
                leftArmMesh.receiveShadow = true;
                leftArmPivot.add(leftArmMesh);
                // Left Hand (Sphere at end of arm)
                var leftHandGeometry = new THREE.SphereGeometry(limbRadius * 1.2, 8, 8);
                var leftHandMesh = new THREE.Mesh(leftHandGeometry, humanMaterial);
                leftHandMesh.position.y = -armLength; // Position hand at the bottom end of the arm
                leftHandMesh.castShadow = true;
                leftHandMesh.receiveShadow = true;
                leftArmPivot.add(leftHandMesh);
                // Right Arm
                var rightArmPivot = new THREE.Group();
                rightArmPivot.position.set(torsoWidth / 2, legLength + torsoHeight - limbRadius, 0); // Shoulder joint
                humanGroup.add(rightArmPivot);
                humanGroup.rightArmPivot = rightArmPivot;
                var rightArmGeometry = new THREE.CylinderGeometry(limbRadius, limbRadius, armLength, 8);
                var rightArmMesh = new THREE.Mesh(rightArmGeometry, humanMaterial);
                rightArmMesh.position.y = -armLength / 2;
                rightArmMesh.castShadow = true;
                rightArmMesh.receiveShadow = true;
                rightArmPivot.add(rightArmMesh);
                // Right Hand (Sphere at end of arm)
                var rightHandGeometry = new THREE.SphereGeometry(limbRadius * 1.2, 8, 8);
                var rightHandMesh = new THREE.Mesh(rightHandGeometry, humanMaterial);
                rightHandMesh.position.y = -armLength;
                rightHandMesh.castShadow = true;
                rightHandMesh.receiveShadow = true;
                rightArmPivot.add(rightHandMesh);
                // Legs (Cylinders) - Left Leg
                var leftLegPivot = new THREE.Group();
                leftLegPivot.position.set(-(torsoWidth / 4), legLength, 0); // Hip joint
                humanGroup.add(leftLegPivot);
                humanGroup.leftLegPivot = leftLegPivot;
                var leftLegGeometry = new THREE.CylinderGeometry(limbRadius, limbRadius, legLength, 8);
                var leftLegMesh = new THREE.Mesh(leftLegGeometry, humanMaterial);
                leftLegMesh.position.y = -legLength / 2; // Offset cylinder so its top is at pivot
                leftLegMesh.castShadow = true;
                leftLegMesh.receiveShadow = true;
                leftLegPivot.add(leftLegMesh);
                // Left Foot (Box at end of leg)
                var leftFootGeometry = new THREE.BoxGeometry(limbRadius * 2, limbRadius, limbRadius * 2.5);
                var leftFootMesh = new THREE.Mesh(leftFootGeometry, humanMaterial);
                leftFootMesh.position.y = -legLength; // Position foot at the bottom of the leg
                leftFootMesh.position.z = limbRadius; // Slight forward offset
                leftFootMesh.castShadow = true;
                leftFootMesh.receiveShadow = true;
                leftLegPivot.add(leftFootMesh);
                // Right Leg
                var rightLegPivot = new THREE.Group();
                rightLegPivot.position.set(torsoWidth / 4, legLength, 0); // Hip joint
                humanGroup.add(rightLegPivot);
                humanGroup.rightLegPivot = rightLegPivot;
                var rightLegGeometry = new THREE.CylinderGeometry(limbRadius, limbRadius, legLength, 8);
                var rightLegMesh = new THREE.Mesh(rightLegGeometry, humanMaterial);
                rightLegMesh.position.y = -legLength / 2;
                rightLegMesh.castShadow = true;
                rightLegMesh.receiveShadow = true;
                rightLegPivot.add(rightLegMesh);
                // Right Foot (Box at end of leg)
                var rightFootGeometry = new THREE.BoxGeometry(limbRadius * 2, limbRadius, limbRadius * 2.5);
                var rightFootMesh = new THREE.Mesh(rightFootGeometry, humanMaterial);
                rightFootMesh.position.y = -legLength;
                rightFootMesh.position.z = limbRadius;
                rightFootMesh.castShadow = true;
                rightFootMesh.receiveShadow = true;
                rightLegPivot.add(rightFootMesh);
                // Position the human 1 meter behind the soap's start Z
                var startPos = this.maze.getStartPosition();
                var humanX = startPos.x;
                var humanY = 0; // Place the group origin at the floor
                var humanZ = startPos.z + 1.0; // 1 meter behind soap's Z
                humanGroup.position.set(humanX, humanY, humanZ);
                humanGroup.castShadow = true; // Group itself doesn't cast shadow, but children do
                this.humanMesh = humanGroup; // Store reference
                this.scene.add(humanGroup);
            }
        },
        {
            key: "start",
            value: function start() {
                this.animate();
            }
        },
        {
            key: "animate",
            value: function animate() {
                var _this = this;
                requestAnimationFrame(this.animate.bind(this));
                var delta = this.clock.getDelta();
                // Only update game elements if playing
                if (this.gameState === GAME_STATE.PLAYING) {
                    this.player.update(delta);
                    // Get title visibility state
                    var ui = this.ui;
                    var titleIsEffectivelyVisible = false;
                    if (ui && ui.elements.title) {
                        titleIsEffectivelyVisible = ui.elements.title.style.display !== 'none';
                    }
                    // Countdown logic
                    if (this.gameState === GAME_STATE.PLAYING) {
                        if (titleIsEffectivelyVisible) {
                            // If title becomes visible again (e.g., game reset but not fully restarted yet), reset countdown state
                            this.countdownActive = false;
                            this.titleHiddenTimestamp = null;
                            this.ui.showCountdownDisplay(false);
                            this.countdownTimer = this.ui.countdownValue; // Reset timer to initial UI value
                        } else {
                            // Title is not visible, game is active
                            if (!this.titleHiddenTimestamp) {
                                // This is the first frame the title is hidden
                                this.titleHiddenTimestamp = this.clock.elapsedTime;
                            }
                            // Start countdown only after title has been hidden
                            if (this.titleHiddenTimestamp && !this.countdownActive) {
                                this.countdownActive = true;
                                this.ui.showCountdownDisplay(true);
                                this.countdownTimer = this.ui.countdownValue; // Ensure timer starts at full duration
                            }
                        }
                        if (this.countdownActive) {
                            this.countdownTimer -= delta;
                            this.ui.updateCountdownDisplay(this.countdownTimer);
                            if (this.countdownTimer <= 0) {
                                this.gameState = GAME_STATE.WON;
                                this.ui.showWinMessage(true, true); // Pass true for isTimeoutWin
                                this.ui.showCountdownDisplay(false); // Hide countdown on win
                                this.countdownActive = false;
                                // Standard win cleanup
                                if (this.humanMesh) this.humanMesh.visible = true;
                                // Soap does NOT disappear on timeout win
                                // if (this.soapMesh) this.scene.remove(this.soapMesh); // Keep soap
                                // this.soapMesh = null; // Keep soap reference
                                this.soapTargetPosition = null; // Still stop any sliding
                                this.humanTargetQueue = [];
                                this.humanIsMoving = false;
                                if (this.humanMesh && this.humanMesh.leftArmPivot) this.humanMesh.leftArmPivot.rotation.x = 0;
                                if (this.humanMesh && this.humanMesh.rightArmPivot) this.humanMesh.rightArmPivot.rotation.x = 0;
                                if (this.humanMesh && this.humanMesh.leftLegPivot) this.humanMesh.leftLegPivot.rotation.x = 0;
                                if (this.humanMesh && this.humanMesh.rightLegPivot) this.humanMesh.rightLegPivot.rotation.x = 0;
                                this.isFKeyPressed = false;
                                this.fKeyHoldTime = 0;
                                this.ui.updateKickIndicator(false);
                                this.ui.updatePickUpIndicator(false);
                                this.ui.updateFKeyProgress(0);
                                clearTimeout(this.restartTimeout);
                                this.restartTimeout = setTimeout(function() {
                                    return _this.restartGame();
                                }, 3000);
                            }
                        }
                    }
                    // Initialize distance and looking state variables, they might be used by F-key logic later
                    var distanceToSoap = Infinity;
                    var isLookingAtSoap = false;
                    if (this.soapMesh && ui) {
                        distanceToSoap = this.player.position.distanceTo(this.soapMesh.position);
                        // Raycast to check if looking at soap (needed for PickUp and F-key logic)
                        this.raycaster.setFromCamera({
                            x: 0,
                            y: 0
                        }, this.camera);
                        var intersects = this.raycaster.intersectObject(this.soapMesh);
                        isLookingAtSoap = intersects.length > 0;
                        // Raycast for general cursor distance
                        var distanceToCursorPoint = null;
                        // Only show Kick/PickUp indicators if game is PLAYING and other conditions are met
                        if (this.gameState === GAME_STATE.PLAYING && !titleIsEffectivelyVisible && !this.player.lookBehind) {
                            this.raycaster.setFromCamera({
                                x: 0,
                                y: 0
                            }, this.camera);
                            // Check against floor and walls for distance calculation
                            // Construct the list of objects for cursor intersection testing
                            var currentObjectsToTest = [];
                            if (this.maze.floorMesh) {
                                currentObjectsToTest.push(this.maze.floorMesh);
                            }
                            if (this.humanMesh) {
                                currentObjectsToTest.push(this.humanMesh);
                            }
                            // Add walls (assuming BoxGeometry, direct scene children, not soap/human group)
                            // This ensures other potential raycast targets are included.
                            this.scene.children.forEach(function(child) {
                                if (child !== _this.maze.floorMesh && // Already added
                                child !== _this.humanMesh && // Already added
                                child !== _this.soapMesh && // Soap is handled separately for pick-up logic
                                child.visible) {
                                    // You might want a more specific check here if you have many dynamic objects
                                    // For now, adding most other visible scene children for general raycasting.
                                    // If walls are specifically tagged or grouped, that would be more robust.
                                    if (!currentObjectsToTest.includes(child)) {
                                        currentObjectsToTest.push(child);
                                    }
                                }
                            });
                            var cursorIntersects = this.raycaster.intersectObjects(currentObjectsToTest, true); // IMPORTANT: true for recursive check
                            var isCursorOnFloor = false; // Initialize
                            var isCursorOnHuman = false; // Initialize isCursorOnHuman here
                            if (cursorIntersects.length > 0) {
                                var intersectionPoint = cursorIntersects[0].point;
                                distanceToCursorPoint = this.player.position.distanceTo(intersectionPoint);
                                var firstIntersectedObject = cursorIntersects[0].object;
                                // Check if the first intersected object is the floor
                                if (firstIntersectedObject === this.maze.floorMesh) {
                                    isCursorOnFloor = true;
                                }
                                // Check if the first intersected object is part of the human
                                // isCursorOnHuman is already initialized above
                                if (this.humanMesh && firstIntersectedObject) {
                                    // Traverse up from the intersected object to see if humanMesh is an ancestor
                                    var currentParentNode = firstIntersectedObject;
                                    while(currentParentNode){
                                        if (currentParentNode === this.humanMesh) {
                                            isCursorOnHuman = true;
                                            break; // Found humanMesh as an ancestor
                                        }
                                        currentParentNode = currentParentNode.parent;
                                    }
                                }
                            }
                            // Show/hide Kick indicator based on distance and new conditions
                            var kickConditionsMet = distanceToSoap >= 0 && distanceToSoap <= 1.76 && isCursorOnFloor && this.humanMesh && this.humanMesh.visible && !isCursorOnHuman; // New condition: cursor not on human
                            ui.updateKickIndicator(kickConditionsMet);
                            // Show/hide Pick Up indicator
                            // PickUp indicator shows if player can initiate the F-key soap interaction (close and looking at soap)
                            // This logic remains independent of the cursor's position on the human, as it's about looking AT the soap.
                            var canInitiateSoapPickup = distanceToSoap >= 0 && distanceToSoap <= 1.76 && isLookingAtSoap;
                            ui.updatePickUpIndicator(canInitiateSoapPickup);
                        // ui.showDistanceIndicator(true); // Removed call
                        } else {
                            ui.updateKickIndicator(false);
                            ui.updatePickUpIndicator(false);
                        // ui.showDistanceIndicator(false); // Removed call
                        }
                    } else if (ui) {
                        // Ensure indicators are hidden if soap doesn't exist or UI is otherwise unavailable
                        ui.updateKickIndicator(false);
                        ui.updatePickUpIndicator(false);
                    // ui.showDistanceIndicator(false); // Removed call
                    }
                    // Update soap position if sliding
                    if (this.soapMesh && this.soapTargetPosition) {
                        var slideSpeed = 10 * delta; // Doubled speed
                        var distanceToTarget = this.soapMesh.position.distanceTo(this.soapTargetPosition);
                        if (distanceToTarget > 0.01) {
                            // Move towards target
                            var direction = this.soapTargetPosition.clone().sub(this.soapMesh.position).normalize();
                            this.soapMesh.position.add(direction.multiplyScalar(Math.min(slideSpeed, distanceToTarget)));
                        } else {
                            // Close enough, snap to target and stop sliding
                            this.soapMesh.position.copy(this.soapTargetPosition);
                            this.soapTargetPosition = null;
                        }
                    }
                    // Make human follow the soap path queue
                    if (this.humanMesh && this.humanTargetQueue.length > 0) {
                        var currentTarget = this.humanTargetQueue[0];
                        // Define the target position for the human (move towards the queued point)
                        var humanTargetPosition = new THREE.Vector3(currentTarget.x, this.humanMesh.position.y, currentTarget.z + 1.0 // Still stay 1 meter behind the target Z
                        );
                        // Calculate movement towards the target
                        var humanFollowSpeed = 3.25; // Set speed to 3.25 meter per second
                        var directionToTarget = humanTargetPosition.clone().sub(this.humanMesh.position);
                        var distanceToTarget1 = directionToTarget.length();
                        this.humanIsMoving = false; // Assume not moving unless distance > threshold
                        if (distanceToTarget1 > 0.05) {
                            this.humanIsMoving = true; // Set flag to true if moving
                            var moveDistance = Math.min(humanFollowSpeed * delta, distanceToTarget1);
                            directionToTarget.normalize();
                            this.humanMesh.position.add(directionToTarget.multiplyScalar(moveDistance));
                        } else {
                            // Reached the current target, remove it from queue
                            this.humanTargetQueue.shift();
                            // If queue becomes empty here, the human just stopped
                            if (this.humanTargetQueue.length === 0) {
                                this.humanIsMoving = false;
                            } else {
                                // Still has targets, so will continue moving next frame
                                this.humanIsMoving = true;
                            }
                        }
                        // Make the human look at the soap (or the next target if queue not empty)
                        var lookAtPosition = this.humanTargetQueue.length > 0 ? this.humanTargetQueue[0] : this.soapMesh ? this.soapMesh.position : this.humanMesh.position.clone().add(new THREE.Vector3(0, 0, -1)); // Look forward if no soap/target
                        var lookAtTarget = lookAtPosition.clone();
                        lookAtTarget.y = this.humanMesh.position.y; // Look level
                        this.humanMesh.lookAt(lookAtTarget);
                    } else if (this.humanMesh && this.soapMesh) {
                        // If queue is empty, make human look at the soap's resting position
                        this.humanIsMoving = false; // Explicitly set to false if queue is empty
                        var lookAtTarget1 = this.soapMesh.position.clone();
                        lookAtTarget1.y = this.humanMesh.position.y; // Look level
                        this.humanMesh.lookAt(lookAtTarget1);
                    }
                    // Walking animation
                    if (this.humanMesh) {
                        var animationSpeed = 7; // Adjust speed of walk cycle
                        var armSwingAngle = Math.PI / 4.5;
                        var legSwingAngle = Math.PI / 4;
                        var walkCycleTime = this.clock.elapsedTime * animationSpeed;
                        if (this.humanIsMoving) {
                            if (this.humanMesh.leftArmPivot) {
                                this.humanMesh.leftArmPivot.rotation.x = Math.sin(walkCycleTime) * armSwingAngle;
                            }
                            if (this.humanMesh.rightArmPivot) {
                                this.humanMesh.rightArmPivot.rotation.x = -Math.sin(walkCycleTime) * armSwingAngle;
                            }
                            if (this.humanMesh.leftLegPivot) {
                                this.humanMesh.leftLegPivot.rotation.x = -Math.sin(walkCycleTime) * legSwingAngle;
                            }
                            if (this.humanMesh.rightLegPivot) {
                                this.humanMesh.rightLegPivot.rotation.x = Math.sin(walkCycleTime) * legSwingAngle;
                            }
                        } else {
                            // Reset rotations if not moving
                            if (this.humanMesh.leftArmPivot) this.humanMesh.leftArmPivot.rotation.x = 0;
                            if (this.humanMesh.rightArmPivot) this.humanMesh.rightArmPivot.rotation.x = 0;
                            if (this.humanMesh.leftLegPivot) this.humanMesh.leftLegPivot.rotation.x = 0;
                            if (this.humanMesh.rightLegPivot) this.humanMesh.rightLegPivot.rotation.x = 0;
                        }
                    }
                    // Handle 'F' key hold interaction
                    if (this.isFKeyPressed && this.soapMesh && !this.player.lookBehind) {
                        if (distanceToSoap <= 1.76 && isLookingAtSoap) {
                            this.fKeyHoldTime += delta;
                            // Update UI progress indicator
                            var progress = Math.min(this.fKeyHoldTime / this.fKeyTargetTime, 1.0);
                            this.ui.updateFKeyProgress(progress);
                            // --- LOSE CONDITION ---
                            // Calculate distance between human and soap
                            var distanceHumanToSoap = this.humanMesh.position.distanceTo(this.soapMesh.position);
                            if (!this.humanIsMoving && this.fKeyHoldTime > 0.1) {
                                this.gameState = GAME_STATE.LOST;
                                this.ui.showLoseMessage(true);
                                this.ui.showCountdownDisplay(false); // Hide countdown on lose
                                this.countdownActive = false;
                                // this.ui.showTitle(true); // Removed
                                // this.ui.showStartMessage(true); // Removed
                                // this.ui.showAuthor(true); // Removed
                                this.isFKeyPressed = false;
                                this.fKeyHoldTime = 0;
                                this.ui.updateKickIndicator(false);
                                this.ui.updatePickUpIndicator(false);
                                this.ui.updateFKeyProgress(0);
                                // Faire disparaître la savonnette en cas de défaite
                                if (this.soapMesh) {
                                    this.scene.remove(this.soapMesh);
                                    this.soapMesh = null;
                                    this.soapTargetPosition = null;
                                }
                                // Faire disparaître l'humain en cas de défaite
                                if (this.humanMesh) {
                                    this.scene.remove(this.humanMesh);
                                    this.humanMesh = null;
                                    this.humanTargetQueue = [];
                                }
                                clearTimeout(this.restartTimeout);
                                this.restartTimeout = setTimeout(function() {
                                    return _this.restartGame();
                                }, 3000);
                            } else if (distanceHumanToSoap <= 1.0 && this.fKeyHoldTime > 0.1) {
                                this.gameState = GAME_STATE.LOST;
                                this.ui.showLoseMessage(true);
                                this.ui.showCountdownDisplay(false); // Hide countdown on lose
                                this.countdownActive = false;
                                // this.ui.showTitle(true); // Removed
                                // this.ui.showStartMessage(true); // Removed
                                // this.ui.showAuthor(true); // Removed
                                this.isFKeyPressed = false;
                                this.fKeyHoldTime = 0;
                                this.ui.updateKickIndicator(false);
                                this.ui.updatePickUpIndicator(false);
                                this.ui.updateFKeyProgress(0);
                                // Faire disparaître la savonnette en cas de défaite
                                if (this.soapMesh) {
                                    this.scene.remove(this.soapMesh);
                                    this.soapMesh = null;
                                    this.soapTargetPosition = null;
                                }
                                // Faire disparaître l'humain en cas de défaite
                                if (this.humanMesh) {
                                    this.scene.remove(this.humanMesh);
                                    this.humanMesh = null;
                                    this.humanTargetQueue = [];
                                }
                                clearTimeout(this.restartTimeout);
                                this.restartTimeout = setTimeout(function() {
                                    return _this.restartGame();
                                }, 3000);
                            } else if (this.fKeyHoldTime >= this.fKeyTargetTime) {
                                this.gameState = GAME_STATE.WON;
                                this.ui.showWinMessage(true, false); // Standard win, not timeout
                                this.ui.showCountdownDisplay(false); // Hide countdown on win
                                this.countdownActive = false;
                                // this.ui.showTitle(true); // Removed
                                // this.ui.showStartMessage(true); // Removed
                                // this.ui.showAuthor(true); // Removed
                                // Removed call to play non-existent win sound
                                // Make human visible again when player wins
                                if (this.humanMesh) {
                                    this.humanMesh.visible = true;
                                }
                                // Clean up soap and interaction state
                                this.scene.remove(this.soapMesh);
                                this.soapMesh = null;
                                this.soapTargetPosition = null;
                                this.humanTargetQueue = []; // Clear the queue
                                this.humanIsMoving = false; // Ensure human stops moving
                                // Reset limb rotations to neutral
                                if (this.humanMesh.leftArmPivot) this.humanMesh.leftArmPivot.rotation.x = 0;
                                if (this.humanMesh.rightArmPivot) this.humanMesh.rightArmPivot.rotation.x = 0;
                                if (this.humanMesh.leftLegPivot) this.humanMesh.leftLegPivot.rotation.x = 0;
                                if (this.humanMesh.rightLegPivot) this.humanMesh.rightLegPivot.rotation.x = 0;
                                this.isFKeyPressed = false;
                                this.fKeyHoldTime = 0;
                                this.ui.updateKickIndicator(false);
                                this.ui.updatePickUpIndicator(false);
                                this.ui.updateFKeyProgress(0);
                                // Schedule restart
                                clearTimeout(this.restartTimeout);
                                this.restartTimeout = setTimeout(function() {
                                    return _this.restartGame();
                                }, 3000);
                            }
                        } else {
                            // Reset timer and hide progress if player moves away or looks away while holding F
                            this.fKeyHoldTime = 0;
                            this.ui.updateFKeyProgress(0);
                            // Make human visible again
                            if (this.humanMesh) {
                                this.humanMesh.visible = true;
                            }
                        }
                    } else {
                        // Reset timer and hide progress if F key is released or no soap
                        this.fKeyHoldTime = 0;
                        if (this.ui) {
                            this.ui.updateFKeyProgress(0);
                        }
                        if (this.humanMesh && this.gameState === GAME_STATE.PLAYING) {
                            var shouldHumanBeVisible = true;
                            // Calculate distToFloorPointIfLookingForward:
                            // This is the distance to where the cursor would hit the floor if the player was looking forward.
                            // Needed for conditions regardless of current facing, as long as title is not visible.
                            var distToFloorPointIfLookingForward = Infinity;
                            if (!titleIsEffectivelyVisible && this.maze.floorMesh && this.player) {
                                var tempRaycastCamera = this.camera.clone();
                                // Configure tempRaycastCamera to player's forward view using player's base rotations
                                var euler = new THREE.Euler(0, this.player.rotationY, 0, 'YXZ'); // Yaw from player
                                tempRaycastCamera.quaternion.setFromEuler(euler);
                                tempRaycastCamera.rotateX(this.player.rotationX); // Pitch from player
                                // Use player's camera position (eye-level) for the raycast origin
                                tempRaycastCamera.position.copy(this.player.camera.position);
                                tempRaycastCamera.updateMatrixWorld(true); // Update matrices after transform changes
                                this.raycaster.setFromCamera({
                                    x: 0,
                                    y: 0
                                }, tempRaycastCamera); // Ray from center of temp forward view
                                var floorIntersects = this.raycaster.intersectObject(this.maze.floorMesh, false); // Non-recursive
                                if (floorIntersects.length > 0) {
                                    // Distance from player's position (eye-level) to the floor intersection point
                                    distToFloorPointIfLookingForward = this.player.position.distanceTo(floorIntersects[0].point);
                                }
                            }
                            // Condition A: F-key is actively being pressed for pickup (looking at soap, close to soap)
                            // This makes the human invisible.
                            var fKeyMakesHumanInvisible = this.isFKeyPressed && distanceToSoap <= 1.76 && isLookingAtSoap;
                            // Condition B: Player is close to soap AND their "forward cursor" (if they were looking forward) 
                            // would be on a nearby floor point. This makes human invisible if title is not showing.
                            // This applies whether the player is currently looking forward or backward.
                            var generalProximityMakesHumanInvisible = false;
                            if (!titleIsEffectivelyVisible) {
                                if (distToFloorPointIfLookingForward >= 0 && distToFloorPointIfLookingForward <= 1.82 && distanceToSoap >= 0 && distanceToSoap <= 1.76) {
                                    generalProximityMakesHumanInvisible = true;
                                }
                            }
                            // Determine final visibility: human is invisible if either condition is true.
                            if (fKeyMakesHumanInvisible || generalProximityMakesHumanInvisible) {
                                shouldHumanBeVisible = false;
                            }
                            this.humanMesh.visible = shouldHumanBeVisible;
                        }
                    }
                } // End of PLAYING state updates
                this.renderer.render(this.scene, this.camera);
            } // End animate method
        },
        {
            key: "onResize",
            value: function onResize() {
                this.width = window.innerWidth;
                this.height = window.innerHeight;
                this.camera.aspect = this.width / this.height;
                this.camera.updateProjectionMatrix();
                this.renderer.setSize(this.width, this.height);
            }
        },
        {
            key: "onMouseDown",
            value: function onMouseDown(event) {
                // Check if pointer is locked (player is controlling camera)
                if (document.pointerLockElement && event.button === 0 && !this.player.lookBehind) {
                    // Check distance to soap and if human is visible
                    if (!this.player || !this.soapMesh || !this.humanMesh || !this.humanMesh.visible) return;
                    var distance = this.player.position.distanceTo(this.soapMesh.position);
                    if (distance >= 0 && distance <= 1.76) {
                        // Raycast from camera center
                        this.mouse.x = 0; // Center of the screen
                        this.mouse.y = 0; // Center of the screen
                        this.raycaster.setFromCamera(this.mouse, this.camera);
                        // Check for intersections
                        var intersects = this.raycaster.intersectObjects(this.scene.children);
                        if (intersects.length > 0) {
                            var firstIntersect = intersects[0];
                            // Check if the intersected object is the floor
                            if (firstIntersect.object === this.maze.floorMesh) {
                                // Move soap to the intersection point on the floor
                                var targetPosition = firstIntersect.point;
                                // Keep soap slightly above floor
                                targetPosition.y = this.soapMesh.geometry.parameters.height / 2;
                                // Set the target position for soap sliding
                                this.soapTargetPosition = targetPosition.clone(); // Clone to avoid reference issues
                                // Add the target position to the human's queue
                                this.humanTargetQueue.push(targetPosition.clone()); // Clone again
                            }
                        }
                    }
                }
            }
        },
        {
            key: "onKeyDown",
            value: function onKeyDown(event) {
                if (event.key.toLowerCase() === 'f') {
                    this.isFKeyPressed = true;
                }
            }
        },
        {
            key: "onKeyUp",
            value: function onKeyUp(event) {
                if (event.key.toLowerCase() === 'f') {
                    this.isFKeyPressed = false;
                    this.fKeyHoldTime = 0; // Reset timer on key release
                    if (this.ui) {
                        this.ui.updateFKeyProgress(0); // Hide progress on key release
                    }
                }
            } // End onKeyUp method
        },
        {
            // Removed closing brace that was prematurely closing the class
            key: "restartGame",
            value: function restartGame() {
                console.log("Restarting game...");
                // Reset game state
                this.gameState = GAME_STATE.PLAYING;
                clearTimeout(this.restartTimeout);
                this.restartTimeout = null;
                // Reset player position
                var startPos = this.maze.getStartPosition();
                this.player.position.set(startPos.x, this.player.height, startPos.z);
                this.camera.position.copy(this.player.position);
                this.player.rotationX = 0; // Reset camera look angle
                this.player.rotationY = 0;
                this.camera.rotation.set(0, 0, 0); // Reset camera rotation explicitly
                this.player.velocity.set(0, 0, 0); // Reset player velocity
                this.player.moveForward = false;
                this.player.moveBackward = false;
                this.player.moveLeft = false;
                this.player.moveRight = false;
                this.player.lookBehind = false;
                // Remove existing soap and human if they somehow persist (safety check)
                if (this.soapMesh) this.scene.remove(this.soapMesh);
                if (this.humanMesh) this.scene.remove(this.humanMesh);
                // Re-add soap
                this.addSoap();
                // Re-add human
                this.addHuman();
                this.humanTargetQueue = []; // Clear human queue
                // Reset interaction state
                this.isFKeyPressed = false;
                this.fKeyHoldTime = 0;
                this.soapTargetPosition = null;
                // Reset UI
                this.ui.showWinMessage(false); // This will reset its text and color due to the UI logic
                this.ui.showLoseMessage(false); // Also hide lose message on restart
                this.ui.updateKickIndicator(false);
                this.ui.updatePickUpIndicator(false);
                this.ui.updateFKeyProgress(0);
                this.ui.showTitle(false); // Hide title on actual game restart
                this.ui.showStartMessage(false); // Hide start message on actual game restart
                this.ui.showAuthor(false); // Hide author credit on actual game restart
                this.ui.showCountdownDisplay(false); // Ensure countdown is hidden on restart
                this.countdownActive = false;
                this.countdownTimer = this.ui.countdownValue; // Reset countdown timer value
                this.titleHiddenTimestamp = null;
                // this.ui.showDistanceIndicator(false); // Ensure distance indicator is hidden on restart
                // Make sure human is visible after restart
                if (this.humanMesh) {
                    this.humanMesh.visible = true;
                }
                // Ensure pointer lock is requested again if needed
                if (!document.pointerLockElement && this.camera.element) {
                // Maybe prompt user to click again? Or just let them click normally.
                }
                console.log("Game restarted.");
            } // End restartGame method
        }
    ]);
    return Game;
} // Add the closing brace for the Game class here
();
