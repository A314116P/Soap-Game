function _class_call_check(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _create_class(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _instanceof(left, right) {
    if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) {
        return !!right[Symbol.hasInstance](left);
    } else {
        return left instanceof right;
    }
}
import * as THREE from 'three';
export var Maze = /*#__PURE__*/ function() {
    "use strict";
    function Maze(scene, game) {
        _class_call_check(this, Maze);
        this.scene = scene;
        this.game = game; // Store reference to game for UI access
        this.cellSize = 3; // 3 meters wide corridors
        this.wallHeight = 3; // 3 meters tall walls
        this.floorMesh = null; // Reference to the floor mesh
        this.showerMaterial = null; // Material for showers
        this.showerGeometry = null; // Geometry for showers
        this.doorMaterial = null; // Material for doors
        // Define the maze layout (0 = path, 1 = wall)
        // This is a simple maze with loops that allow returning to start without turning back
        this.layout = [
            [
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1
            ],
            [
                1,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            [
                1,
                0,
                1,
                0,
                1,
                0,
                1,
                1,
                0,
                1
            ],
            [
                1,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                1
            ],
            [
                1,
                0,
                1,
                1,
                1,
                1,
                0,
                1,
                0,
                1
            ],
            [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                1,
                0,
                1
            ],
            [
                1,
                1,
                1,
                1,
                0,
                1,
                0,
                1,
                0,
                1
            ],
            [
                1,
                0,
                0,
                0,
                0,
                0,
                0,
                1,
                0,
                1
            ],
            [
                1,
                0,
                1,
                1,
                1,
                1,
                1,
                1,
                0,
                1
            ],
            [
                1,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                1
            ],
            [
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1
            ]
        ];
        this.createShowerAssets(); // Prepare shower assets first
        this.createDoorAssets(); // Prepare door assets
        this.createMaze();
        this.createCeilingMarkings(); // Add ceiling markings
    }
    _create_class(Maze, [
        {
            key: "createShowerAssets",
            value: function createShowerAssets() {
                // Shower head (simple cylinder)
                var showerHeadGeometry = new THREE.CylinderGeometry(0.1, 0.15, 0.1, 16);
                // Shower pipe (thin cylinder)
                var pipeGeometry = new THREE.CylinderGeometry(0.03, 0.03, 0.5, 8);
                // Valve/Tap (small box)
                var valveGeometry = new THREE.BoxGeometry(0.08, 0.08, 0.08);
                // Material (metallic look)
                this.showerMaterial = new THREE.MeshStandardMaterial({
                    color: 0xc0c0c0,
                    metalness: 0.9,
                    roughness: 0.4
                });
                // Combine into a group (acts as the geometry for instancing later)
                this.showerGeometry = new THREE.Group();
                var pipe = new THREE.Mesh(pipeGeometry, this.showerMaterial);
                pipe.position.y = 0.25; // Raise pipe slightly
                var showerHead = new THREE.Mesh(showerHeadGeometry, this.showerMaterial);
                showerHead.position.y = 0.5; // Top of the pipe
                showerHead.rotation.x = Math.PI / 6; // Angle downwards
                var valve = new THREE.Mesh(valveGeometry, this.showerMaterial);
                valve.position.y = 0; // Bottom of the pipe
                this.showerGeometry.add(pipe);
                this.showerGeometry.add(showerHead);
                this.showerGeometry.add(valve);
                // Add castShadow / receiveShadow to children if needed individually
                this.showerGeometry.traverse(function(child) {
                    if (_instanceof(child, THREE.Mesh)) {
                        child.castShadow = true;
                        child.receiveShadow = true;
                    }
                });
            }
        },
        {
            key: "createDoorAssets",
            value: function createDoorAssets() {
                this.doorMaterial = new THREE.MeshStandardMaterial({
                    color: 0x8B4513,
                    roughness: 0.85,
                    metalness: 0.05
                });
            }
        },
        {
            key: "createMaze",
            value: function createMaze() {
                // Create floor
                var floorGeometry = new THREE.PlaneGeometry(this.layout[0].length * this.cellSize, this.layout.length * this.cellSize);
                var floorMaterial = new THREE.MeshStandardMaterial({
                    color: 0x8B4513,
                    roughness: 0.7,
                    metalness: 0.1
                });
                var floor = new THREE.Mesh(floorGeometry, floorMaterial);
                floor.rotation.x = -Math.PI / 2;
                floor.position.set(this.layout[0].length * this.cellSize / 2 - this.cellSize / 2, 0, this.layout.length * this.cellSize / 2 - this.cellSize / 2);
                floor.receiveShadow = true;
                this.floorMesh = floor; // Store reference to the floor
                this.scene.add(floor);
                // Create ceiling
                var ceilingGeometry = new THREE.PlaneGeometry(this.layout[0].length * this.cellSize, this.layout.length * this.cellSize);
                var ceilingMaterial = new THREE.MeshStandardMaterial({
                    color: 0xffffff,
                    roughness: 0.8,
                    metalness: 0.2
                });
                var ceiling = new THREE.Mesh(ceilingGeometry, ceilingMaterial);
                ceiling.rotation.x = Math.PI / 2;
                ceiling.position.set(this.layout[0].length * this.cellSize / 2 - this.cellSize / 2, this.wallHeight, this.layout.length * this.cellSize / 2 - this.cellSize / 2);
                ceiling.receiveShadow = true;
                this.scene.add(ceiling);
                // Create walls
                var wallGeometry = new THREE.BoxGeometry(this.cellSize, this.wallHeight, this.cellSize);
                var wallMaterial = new THREE.MeshPhongMaterial({
                    color: 0xffffff,
                    specular: 0x111111,
                    shininess: 10
                });
                // Store wall positions for collision detection
                this.walls = [];
                // Place walls according to layout
                for(var y = 0; y < this.layout.length; y++){
                    for(var x = 0; x < this.layout[y].length; x++){
                        if (this.layout[y][x] === 1) {
                            var wall = new THREE.Mesh(wallGeometry, wallMaterial);
                            wall.position.set(x * this.cellSize, this.wallHeight / 2, y * this.cellSize);
                            wall.castShadow = true;
                            wall.receiveShadow = true;
                            this.scene.add(wall);
                            // Store wall position for collision detection
                            this.walls.push({
                                x: wall.position.x,
                                z: wall.position.z,
                                size: this.cellSize
                            });
                        } else {
                            // Check adjacent cells to place showers on walls bordering paths
                            // Check North (y-1)
                            if (y > 0 && this.layout[y - 1][x] === 1) {
                                // For path cell (x,y):
                                // - Player starts at (1,1). Shower on North wall of (1,1) is kept.
                                // - Path cell (1,2) (layout x=2, y=1) is to the east of start.
                                //   Do not place a shower on its North wall to remove the "middle of three".
                                // - Path cell (1,3) (layout x=3, y=1) is further east. Shower on its North wall is kept.
                                if (!(x === 2 && y === 1)) {
                                    this.placeShower(x, y, 'north');
                                }
                            }
                            // Check South (y+1)
                            if (y < this.layout.length - 1 && this.layout[y + 1][x] === 1) {
                                this.placeShower(x, y, 'south');
                            }
                            // Check West (x-1)
                            if (x > 0 && this.layout[y][x - 1] === 1) {
                                this.placeShower(x, y, 'west');
                            }
                            // Check East (x+1)
                            if (x < this.layout[y].length - 1 && this.layout[y][x + 1] === 1) {
                                // Explicitly do not place a shower on the East wall of path cell (1,1).
                                // Note: The wall at layout[1][2] (east of cell (1,1)) is actually a path (0),
                                // so the outer `this.layout[y][x+1] === 1` check would already prevent
                                // a shower here. This condition is added for explicit adherence to the request.
                                if (!(x === 1 && y === 1)) {
                                    this.placeShower(x, y, 'east');
                                }
                            }
                        }
                    }
                }
                // Add the specific double door
                this.addSpecialDoubleDoor();
            }
        },
        {
            key: "addSpecialDoubleDoor",
            value: function addSpecialDoubleDoor() {
                // Player starts at (1,1), looking towards (1,0) in maze layout (negative Z world)
                // Wall cell is layout[0][1]
                var wallCellXIndex = 1;
                var wallCellZIndex = 0;
                var doorHeight = 2.1;
                var eachDoorWidth = 0.7;
                var doorThickness = 0.1;
                // Calculate position of the wall face player is looking at
                var wallBlockCenterX = wallCellXIndex * this.cellSize;
                var wallBlockCenterZ = wallCellZIndex * this.cellSize;
                // Player looks at the +Z face of the wall block at (1,0)
                var doorFacePlaneZ = wallBlockCenterZ + this.cellSize / 2;
                // Shift the center of the double door to the right by a full cell size (3 units)
                // Original doorFaceCenterX was wallBlockCenterX
                // New doorFaceCenterX is shifted further to the right.
                var doorShiftAmount = this.cellSize; // Shift by a full cell width (3 units)
                var doorFaceCenterX = wallBlockCenterX + doorShiftAmount;
                var doorYPosition = doorHeight / 2; // So bottom of door is at Y=0
                // Left Door
                var leftDoorGeometry = new THREE.BoxGeometry(eachDoorWidth, doorHeight, doorThickness);
                var leftDoor = new THREE.Mesh(leftDoorGeometry, this.doorMaterial);
                leftDoor.position.set(doorFaceCenterX - eachDoorWidth / 2, doorYPosition, doorFacePlaneZ - doorThickness / 2 + 0.01 // Shift slightly towards player to prevent z-fighting
                );
                leftDoor.castShadow = true;
                leftDoor.receiveShadow = true;
                leftDoor.frustumCulled = false; // Prevent incorrect culling
                this.scene.add(leftDoor);
                // Right Door
                var rightDoorGeometry = new THREE.BoxGeometry(eachDoorWidth, doorHeight, doorThickness);
                var rightDoor = new THREE.Mesh(rightDoorGeometry, this.doorMaterial);
                rightDoor.position.set(doorFaceCenterX + eachDoorWidth / 2, doorYPosition, doorFacePlaneZ - doorThickness / 2 + 0.01 // Shift slightly towards player to prevent z-fighting
                );
                rightDoor.castShadow = true;
                rightDoor.receiveShadow = true;
                rightDoor.frustumCulled = false; // Prevent incorrect culling
                this.scene.add(rightDoor);
            }
        },
        {
            key: "placeShower",
            value: function placeShower(x, y, facingDirection) {
                // Simple probabilistic placement: 10% chance per eligible wall face
                // if (Math.random() > 0.1) return; // Removed random placement
                var showerInstance = this.showerGeometry.clone(); // Clone the group
                var showerHeightOffset = 1.5; // Place shower head roughly at eye level
                // Calculate position based on cell and direction
                var baseX = x * this.cellSize;
                var baseZ = y * this.cellSize;
                var wallOffset = 0.05; // Slightly off the wall surface
                switch(facingDirection){
                    case 'north':
                        showerInstance.position.set(baseX, showerHeightOffset, baseZ - this.cellSize / 2 + wallOffset);
                        showerInstance.rotation.y = Math.PI; // Rotate 180 degrees
                        break;
                    case 'south':
                        showerInstance.position.set(baseX, showerHeightOffset, baseZ + this.cellSize / 2 - wallOffset);
                        showerInstance.rotation.y = 0;
                        break;
                    case 'west':
                        showerInstance.position.set(baseX - this.cellSize / 2 + wallOffset, showerHeightOffset, baseZ);
                        showerInstance.rotation.y = Math.PI / 2; // Rotate 90 degrees
                        break;
                    case 'east':
                        showerInstance.position.set(baseX + this.cellSize / 2 - wallOffset, showerHeightOffset, baseZ);
                        showerInstance.rotation.y = -Math.PI / 2; // Rotate -90 degrees
                        break;
                }
                this.scene.add(showerInstance);
            }
        },
        {
            key: "getStartPosition",
            value: function getStartPosition() {
                // Start position is at cell 1,1 (first open space)
                return {
                    x: 1 * this.cellSize,
                    z: 1 * this.cellSize
                };
            }
        },
        {
            key: "checkCollision",
            value: function checkCollision(position, playerRadius) {
                var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
                try {
                    // Check collisions with all walls
                    for(var _iterator = this.walls[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                        var wall = _step.value;
                        // Calculate distance from player center to wall center
                        var dx = position.x - wall.x;
                        var dz = position.z - wall.z;
                        // Half sizes (wall is a cube, so half size is half the cell size)
                        var halfWallSize = wall.size / 2;
                        // Calculate overlap on each axis
                        var overlapX = halfWallSize + playerRadius - Math.abs(dx);
                        var overlapZ = halfWallSize + playerRadius - Math.abs(dz);
                        // If both overlaps are positive, we have a collision
                        if (overlapX > 0 && overlapZ > 0) {
                            return true;
                        }
                    }
                } catch (err) {
                    _didIteratorError = true;
                    _iteratorError = err;
                } finally{
                    try {
                        if (!_iteratorNormalCompletion && _iterator.return != null) {
                            _iterator.return();
                        }
                    } finally{
                        if (_didIteratorError) {
                            throw _iteratorError;
                        }
                    }
                }
                // No collision
                return false;
            }
        },
        {
            key: "createCeilingMarkings",
            value: function createCeilingMarkings() {
                var circleRadius = 0.25; // Radius of the white circles
                var circleSegments = 16; // Smoothness of the circles
                var circleGeometry = new THREE.CircleGeometry(circleRadius, circleSegments);
                var circleMaterial = new THREE.MeshBasicMaterial({
                    color: 0xffffff,
                    side: THREE.DoubleSide
                });
                for(var y = 0; y < this.layout.length; y++){
                    for(var x = 0; x < this.layout[y].length; x++){
                        if (this.layout[y][x] === 0) {
                            var circle = new THREE.Mesh(circleGeometry, circleMaterial);
                            // Position the circle at the center of the cell, on the ceiling
                            circle.position.set(x * this.cellSize, this.wallHeight - 0.01, y * this.cellSize);
                            // Rotate the circle to be flat on the ceiling (parallel to XZ plane)
                            circle.rotation.x = -Math.PI / 2;
                            this.scene.add(circle);
                        }
                    }
                }
            }
        }
    ]);
    return Maze;
}();
