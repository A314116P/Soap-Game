function _class_call_check(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _create_class(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
import * as THREE from 'three';
export var Player = /*#__PURE__*/ function() {
    "use strict";
    function Player(camera, maze) {
        _class_call_check(this, Player);
        this.camera = camera;
        this.maze = maze;
        // Initialize camera rotation
        this.camera.rotation.order = 'YXZ'; // Important for FPS-style camera
        // Set initial position at maze starting point
        var startPosition = this.maze.getStartPosition();
        this.position = new THREE.Vector3(startPosition.x, 1.7, startPosition.z);
        this.camera.position.copy(this.position);
        // Movement parameters
        this.moveSpeed = 3.75; // meters per second (increased by 50%)
        this.rotationSpeed = 2.5;
        this.velocity = new THREE.Vector3();
        this.direction = new THREE.Vector3();
        // Player dimensions for collision detection
        this.radius = 0.5; // 1 meter diameter
        this.height = 1.7; // player height
        // Movement controls
        this.moveForward = false;
        this.moveBackward = false;
        this.moveLeft = false;
        this.moveRight = false;
        this.lookBehind = false;
        // Setup controls
        this.setupControls();
    }
    _create_class(Player, [
        {
            key: "setupControls",
            value: function setupControls() {
                var _this = this;
                document.addEventListener('keydown', function(event) {
                    switch(event.key.toLowerCase()){
                        case 's':
                            _this.moveForward = true;
                            break;
                        case 'w':
                            _this.moveBackward = true;
                            break;
                        case 'a':
                            _this.moveLeft = true;
                            break;
                        case 'd':
                            _this.moveRight = true;
                            break;
                        case ' ':
                            _this.lookBehind = true;
                            break;
                    }
                });
                document.addEventListener('keyup', function(event) {
                    switch(event.key.toLowerCase()){
                        case 's':
                            _this.moveForward = false;
                            break;
                        case 'w':
                            _this.moveBackward = false;
                            break;
                        case 'a':
                            _this.moveLeft = false;
                            break;
                        case 'd':
                            _this.moveRight = false;
                            break;
                        case ' ':
                            _this.lookBehind = false;
                            break;
                    }
                });
                // Mouse control properties
                this.mouseSensitivity = 0.002;
                this.rotationX = 0;
                this.rotationY = 0;
                this.minPolarAngle = 0;
                this.maxPolarAngle = Math.PI;
                document.addEventListener('mousemove', function(event) {
                    if (document.pointerLockElement) {
                        // Smooth mouse movement with sensitivity control
                        _this.rotationY -= event.movementX * _this.mouseSensitivity;
                        _this.rotationX -= event.movementY * _this.mouseSensitivity;
                        // Clamp vertical rotation to prevent over-rotation
                        _this.rotationX = Math.max(-Math.PI / 2 + 0.01, Math.min(Math.PI / 2 - 0.01, _this.rotationX));
                        // Apply rotations using quaternions for smoother camera movement
                        var euler = new THREE.Euler(0, _this.rotationY, 0, 'YXZ');
                        _this.camera.quaternion.setFromEuler(euler);
                        _this.camera.rotateX(_this.rotationX);
                    }
                });
                // Setup pointer lock
                this.camera.element = document.querySelector('canvas'); // Assuming the canvas is the direct child
                this.camera.element.addEventListener('click', function() {
                    _this.camera.element.requestPointerLock();
                    // Hide the title, start message, and author credit when pointer lock is requested
                    if (_this.maze && _this.maze.game && _this.maze.game.ui) {
                        _this.maze.game.ui.showTitle(false);
                        _this.maze.game.ui.showStartMessage(false); // Hide start message
                        _this.maze.game.ui.showAuthor(false); // Hide author credit
                    }
                });
            }
        },
        {
            key: "update",
            value: function update(delta) {
                // Reset velocity
                this.velocity.set(0, 0, 0);
                // Handle look-behind rotation and crosshair visibility
                var ui = this.maze.game && this.maze.game.ui;
                var titleIsEffectivelyVisible = false;
                if (ui && ui.elements.title && ui.elements.crosshair && ui.elements.lookBehindCursor) {
                    titleIsEffectivelyVisible = ui.elements.title.style.display !== 'none';
                    if (titleIsEffectivelyVisible) {
                        ui.elements.crosshair.style.display = 'none';
                        ui.updateLookBehindCursor(false);
                    } else {
                        // when the game is active (title is not visible).
                        if (this.lookBehind) {
                            ui.elements.crosshair.style.display = 'none';
                        } else {
                            ui.elements.crosshair.style.display = 'block';
                        }
                        ui.updateLookBehindCursor(false); // Keep look-behind arrow hidden
                    }
                }
                // Apply camera rotation for look-behind separately
                if (this.lookBehind) {
                    this.camera.rotation.y = this.rotationY + Math.PI;
                } else {
                    this.camera.rotation.y = this.rotationY;
                }
                // Calculate movement direction based on key presses
                if (this.lookBehind) {
                    // Invert forward/backward and left/right controls when looking behind
                    this.direction.z = Number(this.moveBackward) - Number(this.moveForward);
                    this.direction.x = Number(this.moveLeft) - Number(this.moveRight);
                } else {
                    this.direction.z = Number(this.moveForward) - Number(this.moveBackward);
                    this.direction.x = Number(this.moveRight) - Number(this.moveLeft);
                }
                this.direction.normalize();
                // Calculate velocity based on camera direction
                if (this.moveForward || this.moveBackward) {
                    this.velocity.z = this.direction.z * this.moveSpeed * delta;
                }
                if (this.moveLeft || this.moveRight) {
                    this.velocity.x = this.direction.x * this.moveSpeed * delta;
                }
                // Rotate velocity vector based on camera rotation
                var rotation = new THREE.Matrix4().makeRotationY(this.camera.rotation.y);
                this.velocity.applyMatrix4(rotation);
                // Calculate new position with collision detection
                var newPosition = this.position.clone().add(this.velocity);
                // Check for collisions with maze walls
                if (!this.maze.checkCollision(newPosition, this.radius)) {
                    this.position.copy(newPosition);
                    this.camera.position.copy(this.position);
                }
            }
        }
    ]);
    return Player;
}();
