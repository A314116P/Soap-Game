function _class_call_check(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _create_class(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
export var UI = /*#__PURE__*/ function() {
    "use strict";
    function UI(container) {
        _class_call_check(this, UI);
        this.container = container;
        this.elements = {};
        this.fKeyProgress = 0; // Track progress for the indicator
        this.countdownValue = 30; // Initial countdown value in seconds
        this.createUI();
    }
    _create_class(UI, [
        {
            key: "createUI",
            value: function createUI() {
                // Create Game Title
                this.elements.title = document.createElement('div');
                this.elements.title.style.position = 'absolute';
                this.elements.title.style.top = '10%'; // Position near the top
                this.elements.title.style.left = '50%';
                this.elements.title.style.transform = 'translateX(-50%)';
                this.elements.title.style.color = 'white';
                this.elements.title.style.fontSize = '36px';
                this.elements.title.style.fontFamily = "'Arial Black', Gadget, sans-serif";
                this.elements.title.style.fontWeight = 'bold';
                this.elements.title.style.textShadow = '2px 2px 5px rgba(0,0,0,0.6)';
                this.elements.title.textContent = 'Soap Game'; // Set the title text
                this.elements.title.style.display = 'block'; // Make it visible by default
                this.elements.title.style.textAlign = 'center';
                this.container.appendChild(this.elements.title);
                // Create Start Message
                this.elements.startMessage = document.createElement('div');
                this.elements.startMessage.style.position = 'absolute';
                this.elements.startMessage.style.top = 'calc(40% + 50px)'; // Lowered position further
                this.elements.startMessage.style.left = '50%';
                this.elements.startMessage.style.transform = 'translateX(-50%)';
                this.elements.startMessage.style.color = 'white';
                this.elements.startMessage.style.fontSize = '24px'; // Smaller than title
                this.elements.startMessage.style.fontFamily = 'Arial, sans-serif';
                this.elements.startMessage.style.textShadow = '1px 1px 3px rgba(0,0,0,0.5)';
                this.elements.startMessage.textContent = 'Click to Start';
                this.elements.startMessage.style.display = 'block'; // Visible by default
                this.elements.startMessage.style.textAlign = 'center';
                this.container.appendChild(this.elements.startMessage);
                // Create Author Credit
                this.elements.authorCredit = document.createElement('div');
                this.elements.authorCredit.style.position = 'absolute';
                this.elements.authorCredit.style.top = 'calc(10% + 50px)'; // Positioned just below the title
                this.elements.authorCredit.style.left = '50%';
                this.elements.authorCredit.style.transform = 'translateX(-50%)';
                this.elements.authorCredit.style.color = 'white';
                this.elements.authorCredit.style.fontSize = '18px'; // Smaller than title/start
                this.elements.authorCredit.style.fontFamily = 'Arial, sans-serif';
                this.elements.authorCredit.style.textShadow = '1px 1px 2px rgba(0,0,0,0.4)';
                this.elements.authorCredit.textContent = 'by Pyrogamz';
                this.elements.authorCredit.style.display = 'block'; // Visible by default
                this.elements.authorCredit.style.textAlign = 'center';
                this.container.appendChild(this.elements.authorCredit);
                // Create crosshair
                // Create crosshair container
                this.elements.crosshair = document.createElement('div');
                this.elements.crosshair.style.position = 'absolute';
                this.elements.crosshair.style.top = '50%';
                this.elements.crosshair.style.left = '50%';
                this.elements.crosshair.style.width = '20px';
                this.elements.crosshair.style.height = '20px';
                this.elements.crosshair.style.transform = 'translate(-50%, -50%)';
                this.elements.crosshair.style.pointerEvents = 'none';
                this.elements.crosshair.style.display = 'none'; // Initially hidden as title is visible
                // Create Look Behind Cursor
                this.elements.lookBehindCursor = document.createElement('div');
                this.elements.lookBehindCursor.style.position = 'absolute';
                this.elements.lookBehindCursor.style.top = '50%';
                this.elements.lookBehindCursor.style.left = '50%';
                this.elements.lookBehindCursor.style.transform = 'translate(-50%, -50%)';
                this.elements.lookBehindCursor.style.color = 'rgba(255, 255, 255, 0.7)';
                this.elements.lookBehindCursor.style.fontSize = '30px';
                this.elements.lookBehindCursor.style.fontFamily = 'Arial, sans-serif';
                this.elements.lookBehindCursor.style.textShadow = '1px 1px 2px rgba(0,0,0,0.5)';
                this.elements.lookBehindCursor.textContent = '↷'; // Anticlockwise open circle arrow
                this.elements.lookBehindCursor.style.display = 'none'; // Initially hidden
                this.elements.lookBehindCursor.style.pointerEvents = 'none';
                // Create vertical line
                var verticalLine = document.createElement('div');
                verticalLine.style.position = 'absolute';
                verticalLine.style.left = '50%';
                verticalLine.style.top = '0';
                verticalLine.style.width = '2px';
                verticalLine.style.height = '100%';
                verticalLine.style.backgroundColor = 'rgba(255, 255, 255, 0.8)';
                verticalLine.style.transform = 'translateX(-50%)';
                // Create horizontal line
                var horizontalLine = document.createElement('div');
                horizontalLine.style.position = 'absolute';
                horizontalLine.style.top = '50%';
                horizontalLine.style.left = '0';
                horizontalLine.style.width = '100%';
                horizontalLine.style.height = '2px';
                horizontalLine.style.backgroundColor = 'rgba(255, 255, 255, 0.8)';
                horizontalLine.style.transform = 'translateY(-50%)';
                this.elements.crosshair.appendChild(verticalLine);
                this.elements.crosshair.appendChild(horizontalLine);
                // Create F-key progress circle SVG
                this.elements.fProgressCircle = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
                this.elements.fProgressCircle.setAttribute('width', '30'); // Slightly larger than crosshair
                this.elements.fProgressCircle.setAttribute('height', '30');
                this.elements.fProgressCircle.setAttribute('viewBox', '0 0 30 30');
                this.elements.fProgressCircle.style.position = 'absolute';
                this.elements.fProgressCircle.style.top = '50%';
                this.elements.fProgressCircle.style.left = '50%';
                this.elements.fProgressCircle.style.transform = 'translate(-50%, -50%) rotate(-90deg)'; // Rotate to start at top
                this.elements.fProgressCircle.style.pointerEvents = 'none';
                this.elements.fProgressCircle.style.display = 'none'; // Hidden by default
                var circleBG = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
                circleBG.setAttribute('cx', '15');
                circleBG.setAttribute('cy', '15');
                circleBG.setAttribute('r', '13'); // Radius
                circleBG.setAttribute('fill', 'none');
                circleBG.setAttribute('stroke', 'rgba(0, 0, 0, 0.3)'); // Background stroke
                circleBG.setAttribute('stroke-width', '3');
                this.elements.fProgressIndicator = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
                this.elements.fProgressIndicator.setAttribute('cx', '15');
                this.elements.fProgressIndicator.setAttribute('cy', '15');
                this.elements.fProgressIndicator.setAttribute('r', '13');
                this.elements.fProgressIndicator.setAttribute('fill', 'none');
                this.elements.fProgressIndicator.setAttribute('stroke', 'rgba(255, 255, 255, 0.9)'); // White progress
                this.elements.fProgressIndicator.setAttribute('stroke-width', '3');
                var circumference = 2 * Math.PI * 13;
                this.elements.fProgressIndicator.style.strokeDasharray = circumference;
                this.elements.fProgressIndicator.style.strokeDashoffset = circumference; // Start fully empty
                this.elements.fProgressIndicator.style.transition = 'stroke-dashoffset 0.1s linear'; // Smooth transition
                this.elements.fProgressCircle.appendChild(circleBG);
                this.elements.fProgressCircle.appendChild(this.elements.fProgressIndicator);
                this.container.appendChild(this.elements.fProgressCircle);
                this.container.appendChild(this.elements.crosshair); // Add crosshair on top
                this.container.appendChild(this.elements.lookBehindCursor); // Add look-behind cursor
                // Create Kick indicator element
                this.elements.kickIndicator = document.createElement('div');
                this.elements.kickIndicator.style.position = 'absolute';
                this.elements.kickIndicator.style.bottom = '10px';
                this.elements.kickIndicator.style.left = '10px'; // Changed from right to left
                this.elements.kickIndicator.style.color = 'white';
                this.elements.kickIndicator.style.fontSize = '24px'; // Larger font
                this.elements.kickIndicator.style.fontFamily = 'Arial, sans-serif';
                this.elements.kickIndicator.style.fontWeight = 'bold'; // Bold text
                this.elements.kickIndicator.style.textShadow = '2px 2px 4px black'; // Stronger shadow
                this.elements.kickIndicator.textContent = 'Kick';
                this.elements.kickIndicator.style.display = 'none'; // Hidden by default
                this.container.appendChild(this.elements.kickIndicator);
                // Create Pick Up indicator element
                this.elements.pickUpIndicator = document.createElement('div');
                this.elements.pickUpIndicator.style.position = 'absolute';
                this.elements.pickUpIndicator.style.bottom = '40px'; // Position above kick indicator (10px + 24px font + 6px padding)
                this.elements.pickUpIndicator.style.left = '10px';
                this.elements.pickUpIndicator.style.color = 'white';
                this.elements.pickUpIndicator.style.fontSize = '18px'; // Slightly smaller than Kick
                this.elements.pickUpIndicator.style.fontFamily = 'Arial, sans-serif';
                this.elements.pickUpIndicator.style.fontWeight = 'bold';
                this.elements.pickUpIndicator.style.textShadow = '1px 1px 3px black';
                this.elements.pickUpIndicator.textContent = 'Pick up';
                this.elements.pickUpIndicator.style.display = 'none'; // Hidden by default
                this.container.appendChild(this.elements.pickUpIndicator);
                // Create Win Message element
                this.elements.winMessage = document.createElement('div');
                this.elements.winMessage.style.position = 'absolute';
                this.elements.winMessage.style.top = '40%'; // Position slightly above center
                this.elements.winMessage.style.left = '50%';
                this.elements.winMessage.style.transform = 'translate(-50%, -50%)';
                this.elements.winMessage.style.color = '#4CAF50'; // Green color
                this.elements.winMessage.style.fontSize = '48px';
                this.elements.winMessage.style.fontFamily = "'Arial Black', Gadget, sans-serif";
                this.elements.winMessage.style.fontWeight = 'bold';
                this.elements.winMessage.style.textShadow = '2px 2px 5px rgba(0,0,0,0.7)';
                this.elements.winMessage.textContent = 'YOU WIN';
                this.elements.winMessage.style.display = 'none'; // Hidden by default
                this.elements.winMessage.style.textAlign = 'center';
                this.elements.winMessage.dataset.defaultText = 'YOU WIN'; // Store default text
                this.elements.winMessage.dataset.defaultColor = '#4CAF50'; // Store default color
                this.container.appendChild(this.elements.winMessage);
                // Create Lose Message element
                this.elements.loseMessage = document.createElement('div');
                this.elements.loseMessage.style.position = 'absolute';
                this.elements.loseMessage.style.top = '40%'; // Same position as win message
                this.elements.loseMessage.style.left = '50%';
                this.elements.loseMessage.style.transform = 'translate(-50%, -50%)';
                this.elements.loseMessage.style.color = '#DC143C'; // Crimson red color
                this.elements.loseMessage.style.fontSize = '48px';
                this.elements.loseMessage.style.fontFamily = "'Arial Black', Gadget, sans-serif";
                this.elements.loseMessage.style.fontWeight = 'bold';
                this.elements.loseMessage.style.textShadow = '2px 2px 5px rgba(0,0,0,0.7)';
                this.elements.loseMessage.textContent = 'YOU LOSE'; // Removed exclamation mark
                this.elements.loseMessage.style.display = 'none'; // Hidden by default
                this.elements.loseMessage.style.textAlign = 'center';
                this.container.appendChild(this.elements.loseMessage);
                // Create Countdown Timer Display
                this.elements.countdownTimer = document.createElement('div');
                this.elements.countdownTimer.style.position = 'absolute';
                this.elements.countdownTimer.style.top = '20px'; // Position from the top
                this.elements.countdownTimer.style.left = '20px'; // Position from the left
                this.elements.countdownTimer.style.color = 'white';
                this.elements.countdownTimer.style.fontSize = '28px';
                this.elements.countdownTimer.style.fontFamily = "'Arial Black', Gadget, sans-serif";
                this.elements.countdownTimer.style.fontWeight = 'bold';
                this.elements.countdownTimer.style.textShadow = '2px 2px 4px rgba(0,0,0,0.5)';
                var initialSeconds = Math.floor(this.countdownValue);
                var initialMilliseconds = String(Math.floor((this.countdownValue - initialSeconds) * 100)).padStart(2, '0'); // Display 2 digits for ms
                this.elements.countdownTimer.textContent = "".concat(initialSeconds, ".").concat(initialMilliseconds); // Initial display with 2-digit milliseconds
                this.elements.countdownTimer.style.display = 'none'; // Hidden by default
                this.container.appendChild(this.elements.countdownTimer);
            // Removed creation of placeholder audio elements as no sound files are available
            }
        },
        {
            key: "showTitle",
            value: function showTitle(visible) {
                if (this.elements.title) {
                    this.elements.title.style.display = visible ? 'block' : 'none';
                }
                // If the title is being shown, hide these interactive UI elements.
                if (visible) {
                    if (this.elements.crosshair) {
                        this.elements.crosshair.style.display = 'none';
                    }
                    if (this.elements.kickIndicator) {
                        this.elements.kickIndicator.style.display = 'none';
                    }
                    if (this.elements.pickUpIndicator) {
                        this.elements.pickUpIndicator.style.display = 'none';
                    }
                    this.updateFKeyProgress(0); // Also hide F-key progress when title is shown
                } else {
                    // Crosshair becomes visible by default. player.js's update() will then manage
                    // its visibility based on whether the player is looking behind.
                    if (this.elements.crosshair) {
                        this.elements.crosshair.style.display = 'block';
                    }
                // For kick and pickup indicators, their visibility is entirely managed by
                // game.js (updateKickIndicator, updatePickUpIndicator) during gameplay
                // when the title is hidden. So, no need to explicitly show them here.
                }
            }
        },
        {
            key: "showStartMessage",
            value: function showStartMessage(visible) {
                if (this.elements.startMessage) {
                    this.elements.startMessage.style.display = visible ? 'block' : 'none';
                }
            }
        },
        {
            key: "showAuthor",
            value: function showAuthor(visible) {
                if (this.elements.authorCredit) {
                    this.elements.authorCredit.style.display = visible ? 'block' : 'none';
                }
            }
        },
        {
            key: "updateKickIndicator",
            value: function updateKickIndicator(visible) {
                if (this.elements.kickIndicator) {
                    this.elements.kickIndicator.style.display = visible ? 'block' : 'none';
                }
            }
        },
        {
            key: "updatePickUpIndicator",
            value: function updatePickUpIndicator(visible) {
                if (this.elements.pickUpIndicator) {
                    this.elements.pickUpIndicator.style.display = visible ? 'block' : 'none';
                }
            } // Added missing closing brace
        },
        {
            key: "showWinMessage",
            value: function showWinMessage(visible) {
                var isTimeoutWin = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
                if (this.elements.winMessage) {
                    if (visible) {
                        if (isTimeoutWin) {
                            this.elements.winMessage.textContent = 'TIME OUT';
                            this.elements.winMessage.style.color = 'white';
                        } else {
                            this.elements.winMessage.textContent = this.elements.winMessage.dataset.defaultText;
                            this.elements.winMessage.style.color = this.elements.winMessage.dataset.defaultColor;
                        }
                        this.elements.winMessage.style.display = 'block';
                    } else {
                        this.elements.winMessage.style.display = 'none';
                        // Reset to default when hiding, so next "normal" win shows correctly
                        this.elements.winMessage.textContent = this.elements.winMessage.dataset.defaultText;
                        this.elements.winMessage.style.color = this.elements.winMessage.dataset.defaultColor;
                    }
                // Keep title visible even when win message shows (handled by default now)
                }
            }
        },
        {
            key: "showLoseMessage",
            value: function showLoseMessage(visible) {
                if (this.elements.loseMessage) {
                    this.elements.loseMessage.style.display = visible ? 'block' : 'none';
                // Keep title visible even when lose message shows (handled by default now)
                }
            }
        },
        {
            key: "updateFKeyProgress",
            value: function updateFKeyProgress(progress) {
                this.fKeyProgress = progress;
                if (this.elements.fProgressCircle && this.elements.fProgressIndicator) {
                    if (progress > 0 && progress < 1) {
                        this.elements.fProgressCircle.style.display = 'block';
                        var circumference = 2 * Math.PI * 13; // Radius is 13
                        var offset = circumference * (1 - progress);
                        this.elements.fProgressIndicator.style.strokeDashoffset = offset;
                    } else {
                        // Hide or reset if progress is 0 or 1 (or invalid)
                        this.elements.fProgressCircle.style.display = 'none';
                        var circumference1 = 2 * Math.PI * 13;
                        this.elements.fProgressIndicator.style.strokeDashoffset = circumference1; // Reset to empty
                    }
                }
            }
        },
        {
            key: "updateLookBehindCursor",
            value: function updateLookBehindCursor(visible) {
                if (this.elements.lookBehindCursor) {
                    this.elements.lookBehindCursor.style.display = visible ? 'block' : 'none';
                }
            }
        },
        {
            // Removed updateDistanceIndicator method
            // Removed showDistanceIndicator method
            key: "updateCountdownDisplay",
            value: function updateCountdownDisplay(timeLeft) {
                if (this.elements.countdownTimer) {
                    var totalSeconds = Math.max(0, timeLeft);
                    var seconds = Math.floor(totalSeconds);
                    var milliseconds = Math.floor((totalSeconds - seconds) * 100); // Calculate for 2 digits
                    this.elements.countdownTimer.textContent = "".concat(seconds, ".").concat(String(milliseconds).padStart(2, '0')); // Display 2 digits for ms
                }
            }
        },
        {
            key: "showCountdownDisplay",
            value: function showCountdownDisplay(visible) {
                if (this.elements.countdownTimer) {
                    this.elements.countdownTimer.style.display = visible ? 'block' : 'none';
                    if (visible) {
                        this.updateCountdownDisplay(this.countdownValue); // Reset display when shown
                    }
                }
            }
        }
    ]);
    return UI;
}();
